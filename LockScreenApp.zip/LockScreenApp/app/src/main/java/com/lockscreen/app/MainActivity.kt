package com.lockscreen.app

import android.app.Activity
import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val main = Handler(Looper.getMainLooper())
    private var controller: MediaController? = null
    private var hooked = false
    private var artSentFor = ""
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var immersive = false
    private var immersiveSince = 0L
    @Volatile private var realOn = false

    private fun leaveFull() {
        if (!immersive) return
        immersive = false
        applyImmersive()
        web.evaluateJavascript("window.exitFull&&window.exitFull()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (immersive) {
            leaveFull()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private fun pushNotifs() {
        if (!realOn) return
        val svc = MediaListener.instance ?: return
        val arr = JSONArray()
        try {
            val list = svc.activeNotifications ?: return
            for (sbn in list.sortedByDescending { it.postTime }) {
                if (arr.length() >= 12) break
                if (sbn.packageName == packageName) continue
                val n = sbn.notification
                if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) continue
                if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
                val ex = n.extras
                if (ex.getString(Notification.EXTRA_TEMPLATE)?.contains("MediaStyle") == true) continue
                val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
                val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
                    ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
                if (title.isBlank() && text.isBlank()) continue
                val pkg = sbn.packageName
                val app = when {
                    pkg.startsWith("com.whatsapp") -> "wa"
                    pkg.contains("messaging") || pkg == "com.android.mms" -> "msg"
                    else -> "gen"
                }
                val mins = (System.currentTimeMillis() - sbn.postTime) / 60000
                val time = when {
                    mins < 1 -> "now"
                    mins < 60 -> "${mins}m ago"
                    else -> java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault())
                        .format(java.util.Date(sbn.postTime))
                }
                var pic = ""
                try {
                    val d = n.getLargeIcon()?.loadDrawable(this)
                    if (d != null) {
                        val bmp = Bitmap.createBitmap(120, 120, Bitmap.Config.ARGB_8888)
                        d.setBounds(0, 0, 120, 120)
                        d.draw(android.graphics.Canvas(bmp))
                        val out = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
                        pic = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                    }
                } catch (e: Exception) { }
                arr.put(JSONObject().put("app", app).put("name", title).put("msg", text)
                    .put("time", time).put("pic", pic))
            }
        } catch (e: Exception) {
            return
        }
        web.evaluateJavascript("window.realNotifs&&window.realNotifs($arr)", null)
    }

    private fun applyImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(!immersive)
            val c = window.insetsController
            if (immersive) {
                c?.hide(WindowInsets.Type.systemBars())
                c?.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else {
                c?.show(WindowInsets.Type.systemBars())
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (immersive) {
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            } else {
                View.SYSTEM_UI_FLAG_VISIBLE
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && immersive) applyImmersive()
    }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = push()
        override fun onPlaybackStateChanged(state: PlaybackState?) = push()
    }

    inner class Bridge {
        @JavascriptInterface
        fun openAccess() {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }

        @JavascriptInterface
        fun saveState(s: String) {
            try {
                val tmp = java.io.File(filesDir, "state.tmp")
                tmp.writeText(s)
                tmp.renameTo(java.io.File(filesDir, "state.json"))
            } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun loadState(): String = try {
            val f = java.io.File(filesDir, "state.json")
            if (f.exists()) f.readText() else "{}"
        } catch (e: Exception) { "{}" }

        @JavascriptInterface
        fun setImmersive(on: Boolean) {
            runOnUiThread {
                immersive = on
                if (on) immersiveSince = SystemClock.uptimeMillis()
                applyImmersive()
            }
        }

        @JavascriptInterface
        fun setReal(on: Boolean) {
            realOn = on
            if (on) main.post { pushNotifs() }
        }

        @JavascriptInterface
        fun requestNotifs() {
            main.post { pushNotifs() }
        }

        @JavascriptInterface
        fun hasAccess(): Boolean =
            Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
                ?.contains(packageName) == true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        @Suppress("DEPRECATION")
        web.settings.allowUniversalAccessFromFileURLs = true
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                return try {
                    startActivityForResult(Intent.createChooser(i, "Choose image"), 1)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        MediaListener.onChange = { main.post { pushNotifs() } }
        if (Build.VERSION.SDK_INT >= 30) {
            window.decorView.setOnApplyWindowInsetsListener { v, insets ->
                if (immersive && SystemClock.uptimeMillis() - immersiveSince > 1000 &&
                    insets.isVisible(WindowInsets.Type.navigationBars())) {
                    leaveFull()
                }
                v.onApplyWindowInsets(insets)
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.setOnSystemUiVisibilityChangeListener { vis ->
                if (immersive && SystemClock.uptimeMillis() - immersiveSince > 1000 &&
                    (vis and View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0) {
                    leaveFull()
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onPause() {
        web.evaluateJavascript("window.flushState&&window.flushState()", null)
        super.onPause()
    }

    override fun onDestroy() {
        MediaListener.onChange = null
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        hook()
        pushNotifs()
    }

    private fun hook() {
        val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val cn = ComponentName(this, MediaListener::class.java)
        try {
            if (!hooked) {
                msm.addOnActiveSessionsChangedListener({ list -> pick(list) }, cn)
                hooked = true
            }
            pick(msm.getActiveSessions(cn))
        } catch (e: SecurityException) {
            hooked = false // notification access not granted yet
        }
    }

    private fun pick(list: List<MediaController>?) {
        val c = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        if (c?.sessionToken == controller?.sessionToken) { push(); return }
        controller?.unregisterCallback(callback)
        controller = c
        c?.registerCallback(callback, main)
        push()
    }

    private fun push() {
        val c = controller ?: return
        val m = c.metadata ?: return
        val st = c.playbackState
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val playing = st?.state == PlaybackState.STATE_PLAYING
        var pos = (st?.position ?: 0L).coerceAtLeast(0L)
        if (playing && st != null) {
            pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        }
        val key = "$title|$artist"
        val o = JSONObject()
            .put("title", title).put("artist", artist)
            .put("dur", m.getLong(MediaMetadata.METADATA_KEY_DURATION))
            .put("pos", pos).put("playing", playing)
        if (artSentFor != key) {
            val bmp = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            if (bmp != null) { o.put("art", encode(bmp)); artSentFor = key }
        }
        web.evaluateJavascript("window.nowPlaying&&window.nowPlaying($o)", null)
    }

    private fun encode(b: Bitmap): String {
        val s = 700f / maxOf(b.width, b.height)
        val sc = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
        val out = ByteArrayOutputStream()
        sc.compress(Bitmap.CompressFormat.JPEG, 88, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
