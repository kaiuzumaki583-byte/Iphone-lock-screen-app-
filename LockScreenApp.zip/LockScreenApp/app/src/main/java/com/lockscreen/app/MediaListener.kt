package com.lockscreen.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

// Once the user enables notification access for this app, Android lets it read the
// active media sessions (Spotify, YouTube Music, etc.) and, if switched on in the app,
// the notifications currently shown on the phone. Nothing is sent anywhere.
class MediaListener : NotificationListenerService() {
    companion object {
        @Volatile var instance: MediaListener? = null
        @Volatile var onChange: (() -> Unit)? = null
    }

    override fun onListenerConnected() {
        instance = this
        onChange?.invoke()
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        onChange?.invoke()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        onChange?.invoke()
    }
}
