package com.lockscreen.app

import android.service.notification.NotificationListenerService

// Empty on purpose: once the user enables notification access for this app,
// Android lets it read the active media sessions (Spotify, YouTube Music, etc.).
class MediaListener : NotificationListenerService()
