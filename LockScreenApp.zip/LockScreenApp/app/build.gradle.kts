plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.lockscreen.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.lockscreen.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// Downloads the fonts into the app at build time (skipped quietly if offline)
val fontDir = file("src/main/assets/fonts")
tasks.register("downloadFonts") {
    doLast {
        fontDir.mkdirs()
        val base = "https://cdn.jsdelivr.net/fontsource/fonts"
        mapOf(
            "inter-400" to "inter@latest/latin-400-normal",
            "inter-500" to "inter@latest/latin-500-normal",
            "inter-600" to "inter@latest/latin-600-normal",
            "inter-700" to "inter@latest/latin-700-normal",
            "nunito-800" to "nunito@latest/latin-800-normal",
            "newsreader-600" to "newsreader@latest/latin-600-normal",
            "roboto-slab-700" to "roboto-slab@latest/latin-700-normal",
            "stardos-stencil-700" to "stardos-stencil@latest/latin-700-normal",
            "barlow-condensed-600" to "barlow-condensed@latest/latin-600-normal"
        ).forEach { (name, path) ->
            val f = File(fontDir, "$name.woff2")
            if (!f.exists()) {
                try {
                    val bytes = java.net.URL("$base/$path.woff2").readBytes()
                    if (bytes.size > 2000) f.writeBytes(bytes)
                } catch (e: Exception) {
                    println("Font skipped: $name")
                }
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn("downloadFonts") }
