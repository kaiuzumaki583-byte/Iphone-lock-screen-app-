# Lock Screen (Android) v4
Screen: app/src/main/assets/index.html
New: depth effect (clock behind subject), optional clock/date fonts.
